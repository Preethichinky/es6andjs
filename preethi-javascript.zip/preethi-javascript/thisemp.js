var person={
    firstName:"preethi",
    lastName:"Chinky",
    idNo:45,
    fullName:function(){
        return this.firstName+" "+this.lastName;
    }
};
console.log(person);
console.log(person.fullName());
//alone
var x=this;
console.log(x);
//arrowfun
hello=()=>{
    return "Hello World";
}

hello = () => "Hello World!";
console.log(hello());

var hello;
hello=(val)=>"Hello"+val;
console.log(hello(" Universe"));

//const
const student={section:"fifth",rollNo:12,sport:"hockey"};
console.log(student);
const color=["red","yellow","green"];
color[1]="blue";
color.push("orange");
console.log(color);
//filter
function isPositive(value){
    return value>0;
}
var filtered=[112,52,0,-1,940].filter(isPositive);
console.log(filtered);
function isEven(value) {
    return value % 2 == 0;
  }
  
  var result = [11, 98, 31, 23, 944].filter(isEven);
  console.log(result);
//map
var numbers = [4, 9, 16, 25];
var x = numbers.map(Math.sqrt);
console.log(x);

var numbers = [65, 44, 12, 4];
var newarray = numbers.map(myFunction)

function myFunction(num) {
  return num * 10;
}
console.log(newarray);

var arr = [14, 10, 11, 00]; 
var new_arr = arr.map(Math.sqrt); 
console.log(new_arr);