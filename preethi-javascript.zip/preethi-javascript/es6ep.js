const name="preethi";
console.log(name);
//arrowfn
var fun1=function show(){
    console.log("first");
}
var  fun2=function(){
    console.log("no function");
}
var fun3=()=>{
    console.log("Arrow");
}
fun1();
fun2();
fun3();

var x=value=>value/2;
console.log(x(50));
//templateliterals
const res= 'sum of 4 and 5 ${4+5}';
console.log(res);
console.log(`${res < 10 ? 'Too low': 'Very high'}`);

//default

function say(message='Hi') {
    console.log(message);
}
say(); 
say(undefined); 
say('Hello');

//objectliterals
var obj={
    p1:'hello',
    p2:'world',
    res:function(){
        console.log(this.p1+' '+this.p2);
    }
};
obj.res();

var a=1,b=2,c=3;
obj={
    a:b,
    b:c,
    c:a,
};
console.log(obj);

const output={
    sum(a,b){
        return a+b;
    },
    subtract(a,b){
        return a-b;
    }
};
console.log(output.sum(3,2));
console.log(output.subtract(2,3));
//spreadop
const a1=[1,2,3,4,5];
const a2=[6,7,8,9,10];
const arrayoutput=[...a1, ...a2];
console.log(arrayoutput);

let str=['p',...'ree','t','h','i'];
console.log(str);
//restop
function x(...args){
    let sum=0;
    for(let i of args){
        sum+=i;
    }
    console.log("sum:"+sum);
}
x(1,2,3);
var c=(a,...args)=>{
    console.log(a+" "+args);
}
c(10,20,30);
//destructingop
var numbers=[1,2,3,4,5,6,7,8,9,0];
var[a,b,c,...args]=numbers;
console.log(a);
console.log(b);
console.log(args);

var arr=["hi","hello"];
var[f,s]=arr;
console.log(f);
console.log(s);