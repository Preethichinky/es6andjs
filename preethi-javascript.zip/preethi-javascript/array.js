let a=[];
a=['maths','science','coding'];
console.log(a);
//numberArray
let num=[];
num=[1,2,3,4,5,7,8,9];
console.log(num[0]+num[1]+num[2]);
console.log(num.sort());
num.push(6);
console.log(num);
console.log(num.sort());
//mixing
let mix=[];
mix=['one',1,'two',2];
console.log(mix);
//object
let dog={
    type:'retriever',
    color:'golden',
    age:2,
    breed:['retriever','husky','samoyed','pitbull']
};
console.log(dog);
console.log(dog.type);
console.log(dog.breed[2]);
//Functions
function hello(){
    console.log('Hello');
}
hello();

function add(x,y){
    return x+y;
}
let b=add(2,3);
console.log(b);
//IFELSE statements
let number=[1,2,5,2,34,1,3];
if(number[0]==number[5] && number[1]==number[3]){
    console.log("Correct");
}
else{
    console.log("Wrong");
}
//loops
let k=0;
while(k<3){
    console.log(k);
    k++;
}
for(i=0;i<2;i++){
    console.log("The value of i is " +i);
}
//switch
let chocolate='brownchocolate';
switch(chocolate){
    case "whitechocolate":console.log("false");break;
    case "darkchocolate":console.log("false");break;
    case "brownchocolate":console.log("true");break;
    default:console.log("chocolate");break;
}