console.log('Hello World');
let name='Preethi';
let age=1;
console.log(name);
console.log(age);
let option="true";
let a;
console.log(option);
console.log(a);
